import Header from '../components/Header'
import { Container, Row, Col } from 'react-bootstrap' 

const Cart = () => {
  return (
    <div className="Cart">
        <Header/>
        <Container>
            <Row>
                Cart Page
            </Row>
        </Container>
    </div>
  )
}

export default Cart