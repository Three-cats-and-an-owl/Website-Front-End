import Header from '../components/Header'
import { Container, Row, Col } from 'react-bootstrap'

const Inventory = () => {
  return (
    <div className="Inventory">
      <Header/>
      <Container>
            <Row>
                Inventory Page
            </Row>
        </Container>
    </div>
  )
}

export default Inventory